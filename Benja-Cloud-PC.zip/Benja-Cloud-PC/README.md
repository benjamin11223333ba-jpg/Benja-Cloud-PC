# Benja Cloud PC ULTRA

Projeto experimental para desenvolver um ambiente de desktop remoto.

## O que esta versao faz

- Usa GitHub Actions para validar os arquivos em um runner Windows temporario.
- Consulta informacoes basicas do Windows, CPU e memoria.
- Mantem a RTX 4090 apenas como referencia visual/simulada.

## O que esta versao ainda nao faz

- Nao cria uma maquina virtual Windows permanente.
- Nao fornece acesso remoto por RDP.
- Nao cria uma GPU NVIDIA ou aumenta o desempenho grafico.
- Nao mantem o runner ligado depois que o workflow termina.
- Nao oferece armazenamento persistente para uma sessao do runner.

## Como executar

1. Envie os arquivos deste projeto para um repositorio GitHub chamado `Benja-Cloud-PC`.
2. Abra a aba **Actions**.
3. Selecione **Benja Cloud PC ULTRA - Validacao**.
4. Clique em **Run workflow**.

Um resultado verde significa apenas que a validacao terminou corretamente no runner temporario do GitHub.

## Proximas etapas

Para ter um desktop remoto de verdade, sera necessario escolher uma hospedagem que permita executar um sistema operacional e um servidor de acesso remoto. O GitHub pode continuar sendo usado para guardar o codigo e automatizar atualizacoes.
