$ErrorActionPreference = "Stop"

Write-Host "========================================"
Write-Host "       BENJA CLOUD PC ULTRA"
Write-Host "       VALIDACAO DO RUNNER"
Write-Host "========================================"

$os = Get-CimInstance -ClassName Win32_OperatingSystem
$cpu = Get-CimInstance -ClassName Win32_Processor

if (-not $os) {
    throw "Nao foi possivel consultar o sistema operacional."
}

if (-not $cpu) {
    throw "Nao foi possivel consultar o processador."
}

$totalRamGB = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
$freeRamGB = [math]::Round($os.FreePhysicalMemory / 1MB, 2)

Write-Host "Sistema operacional: $($os.Caption)"
Write-Host "Arquitetura: $($os.OSArchitecture)"
Write-Host "Processador: $($cpu.Name)"
Write-Host "Nucleos: $($cpu.NumberOfCores)"
Write-Host "RAM total visivel: $totalRamGB GB"
Write-Host "RAM livre no momento: $freeRamGB GB"

Write-Host ""
Write-Host "GPU de referencia: RTX 4090 (SIMULACAO VISUAL)"
Write-Host "GPU fisica: nao presumida nem criada."
Write-Host "FPS: nao medido por este teste."

Write-Host ""
Write-Host "Resultado: o ambiente temporario foi verificado."
Write-Host "Aviso: este script NAO instala nem inicia um desktop remoto."
